<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        #popup_table {
            display: none;
        }

        .dtHorizontalExampleWrapper {
            max-width: 600px;
            margin: 0 auto;
        }

        #dtHorizontalExample th,
        td {
            white-space: nowrap;
        }

        table.dataTable thead .sorting:after,
        table.dataTable thead .sorting:before,
        table.dataTable thead .sorting_asc:after,
        table.dataTable thead .sorting_asc:before,
        table.dataTable thead .sorting_asc_disabled:after,
        table.dataTable thead .sorting_asc_disabled:before,
        table.dataTable thead .sorting_desc:after,
        table.dataTable thead .sorting_desc:before,
        table.dataTable thead .sorting_desc_disabled:after,
        table.dataTable thead .sorting_desc_disabled:before {
            bottom: .5em;
        }

        div.scrollmenu {

            overflow: auto;
            white-space: nowrap;
        }
    </style>

</head>

<body class="nav-md">



    <div class="container body">
        <div class="main_container">
            @include('main_admin.sidebar.sidebar')
            <div class="right_col" role="main" style="min-height:800px !important;">
                <div class="row">
                    <div class="">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Show Current Bet Of Game</h2>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <div class="col-md-12 col-xs-12">
                                    <a data-toggle="modal" class="btn btn-primary" data-target="#popup_table" id="show_history1"
                                onclick="show_Bet_history()" style="cursor: pointer;"><i class="fa fa-calendar"></i> Show All History</a>
                                <a href="{{url('SetWinNo')}}" class="btn btn-info">Set Win No</a>
                                </div>

                                <div class="col-md-6" style="margin-top: 25px;">
                                    <div class="flash-message">
                                        @if(Session::has('message'))
                                        <p class="alert {{ Session::get('alert-class', 'alert-success') }}"
                                            style="font-size: 17px">
                                            {{ Session::get('message') }}</p>
                                        {{ Session::forget('message') }}
                                        @endif
                                        @if(Session::has('error'))
                                        <p class="alert {{ Session::get('alert-class', 'alert-danger') }}"
                                            style="font-size: 17px">
                                            {{ Session::get('error') }}</p>
                                        {{ Session::forget('error') }}
                                        @endif
                                    </div>

                                </div>
                                <br />


                            </div>
                        </div>
                    </div>

                </div>
                <div class="container x_panel">
                    <div class="row">
                        {{-- <div class="col-md-2"></div> --}}
                        <div class="col-md-12 col-xs-12">
                            {{-- <p class="alert alert-success text-center"><strong>{{$day}}</strong></p> --}}
                            <table id="dtHorizontalExample" class="table  table-bordered" cellspacing="0" width="100%">
                                <thead>
                                    <tr class="text-center">
                                        <th>Round Count</th>
                                        <th>0</th>
                                        <th>1</th>
                                        <th>2</th>
                                        <th>3</th>
                                        <th>4</th>
                                        <th>5</th>
                                        <th>6</th>
                                        <th>7</th>
                                        <th>8</th>
                                        <th>9</th>
                                        <th>Created At</th>
                                        {{-- <th>Franchise</th> --}}
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($data != 0)
                                    @foreach ($bet_data as $history_point)
                                    <tr class="text-center">
                                        <td>{{$history_point->round_count }}</td>
                                        @if($history_point->no_0 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_0}}</td>
                                        @endif

                                        @if($history_point->no_1 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_1}}</td>
                                        @endif

                                        @if($history_point->no_2 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_2}}</td>
                                        @endif

                                        @if($history_point->no_3 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_3}}</td>
                                        @endif

                                        @if($history_point->no_4 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_4}}</td>
                                        @endif
                                        @if($history_point->no_5 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_5}}</td>
                                        @endif

                                        @if($history_point->no_6 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_6}}</td>
                                        @endif

                                        @if($history_point->no_7 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_7}}</td>
                                        @endif

                                        @if($history_point->no_8 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_8}}</td>
                                        @endif

                                        @if($history_point->no_9 == null)
                                        <td>0</td>
                                        @else
                                        <td>{{$history_point->no_9}}</td>
                                        @endif

                                        <td>{{$history_point->created_at}}</td>
                                        {{-- <td><strong>Admin</strong></td> --}}
                                    </tr>
                                    @endforeach
                                    @else
                                    <tr>
                                        <td colspan="4" class="text-center"
                                            style="background: lightgrey;color:#000;font-size:18px">Data Not Found</td>
                                    </tr>
                                    @endif
                                </tbody>
                                <tfoot>
                                    <tr class="text-center">
                                        <th>Round Count</th>
                                        <th>0</th>
                                        <th>1</th>
                                        <th>2</th>
                                        <th>3</th>
                                        <th>4</th>
                                        <th>5</th>
                                        <th>6</th>
                                        <th>7</th>
                                        <th>8</th>
                                        <th>9</th>
                                        <th>Created At</th>
                                        {{-- <th>Franchise</th> --}}
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div> {{-- End Of x_panel --}}
            </div>
        </div>
    </div>



    <div class="modal fade" id="popup_table" role="dialog" style="margin-top:35px">
        <div class="col-md-2"></div>
        <div class=" col-md-8 col-xs-12 text-center">
            <div class="x_panel scrollmenu">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <table id="dtHorizontalExample" class="table table-bordered my-table" cellspacing="0" width="100%">
                    <thead>
                        <tr class="text-center">
                            <th>Round Count</th>
                            <th>0</th>
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>7</th>
                            <th>8</th>
                            <th>9</th>
                            <th>Created At</th>
                            {{-- <th>Franchise</th> --}}
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                    <tfoot>
                        <tr class="text-center">
                            <th>Round Count</th>
                            <th>0</th>
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>7</th>
                            <th>8</th>
                            <th>9</th>
                            <th>Created At</th>
                            {{-- <th>Franchise</th> --}}
                        </tr>
                    </tfoot>
                </table>
            </div> {{-- End Of x_panel --}}
        </div>
    </div>

    <!-- jQuery -->
    <script src="{{url('vendors/jquery/dist/jquery.min.js')}}"></script>
    <!-- Bootstrap -->
    <script src="{{url('vendors/bootstrap/dist/js/bootstrap.min.js')}}"></script>
    <!-- FastClick -->
    <script src="{{url('vendors/fastclick/lib/fastclick.js')}}"></script>
    <!-- NProgress -->
    <script src="{{url('vendors/nprogress/nprogress.js')}}"></script>
    <!-- iCheck -->
    <script src="{{url('vendors/iCheck/icheck.min.js')}}"></script>
    <!-- Datatables -->
    <script src="{{url('vendors/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-buttons/js/buttons.flash.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{url('vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')}}"></script>
    <script src="{{url('vendors/datatables.net-scroller/js/dataTables.scroller.min.js')}}"></script>
    <script src="{{url('vendors/jszip/dist/jszip.min.js')}}"></script>
    <script src="{{url('vendors/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{url('vendors/pdfmake/build/vfs_fonts.js')}}"></script>

    <!-- Switchery -->
    <script src="{{url('vendors/switchery/dist/switchery.min.js')}}"></script>
    <!-- Custom Theme Scripts -->
    <script src="{{url('build/js/custom.min.js')}}"></script>
    <script>
        $(document).ready(function () {
$('#dtHorizontalExample').DataTable({
"scrollX": true
});
$('.dataTables_length').addClass('bs-select');
});

// $('.datepicker').datepicker({
//     startDate: '-3d'
// });

$(document).ready(function(){
    $('#UserPointHistory').click(function(){
        // alert("okkk");
        console.log("okkk");

    });
});
    </script>

    <script>
        function show_Bet_history(){
            var url = window.location.origin+'/GetAllBetData';
        $.ajax({
            url: url,
            type: 'get',
            dataType: 'json',
            success:function(response){
                var len = 0;
                $('#popup_table').css('display','block');
                $('.my-table tbody').empty();
                if(response['data'] != null){
                    len = response['data'].length;
                }
                for(var i=0; i<len; i++){
                    var no_0,no_1,no_2,no_3,no_4,no_5,no_6,no_7,no_8,no_9;
                    var round_count = response['data'][i].round_count;
                    if(response['data'][i].no_0 == null){
                        no_0 = 0;
                    }else{
                     no_0 = response['data'][i].no_0;
                    }

                    if(response['data'][i].no_1 == null){
                        no_1 =0;
                    }else{
                     no_1 = response['data'][i].no_1;
                    }
                    if(response['data'][i].no_2 == null){
                        no_2 = 0;
                    }else{
                     no_2 = response['data'][i].no_2;
                    }
                     if(response['data'][i].no_3 == null){
                         no_3 =0;
                     }else{
                     no_3 = response['data'][i].no_3;
                     }
                     if(response['data'][i].no_4 == null){
                         no_4 = 0;
                     }else{
                     no_4 = response['data'][i].no_4;
                     }
                     if(response['data'][i].no_5 == null){
                         no_5=0;
                     }else{
                     no_5 = response['data'][i].no_5;
                     }
                     if(response['data'][i].no_6 == null){
                         no_6 = 0;
                     }else{
                     no_6 = response['data'][i].no_6;
                     }
                     if(response['data'][i].no_7 == null){
                         no_7 = 0;
                     }else{
                     no_7 = response['data'][i].no_7;
                     }
                     if(response['data'][i].no_8 == null){
                         no_8 = 0;
                     }else{
                     no_8 = response['data'][i].no_8;
                     }
                     if(response['data'][i].no_9 == null){
                         no_9 =0;
                     }else{
                     no_9 = response['data'][i].no_9;
                     }
                    var created_at = response['data'][i].created_at;

                    var tr_str = "<tr>" +
                        "<td align='center'>" + round_count + "</td>" +
                   "<td align='center'>" + no_0 + "</td>" +
                   "<td align='center'>" + no_1 + "</td>" +
                   "<td align='center'>" + no_2 + "</td>" +
                   "<td align='center'>" + no_3 + "</td>" +
                   "<td align='center'>" + no_4 + "</td>" +
                   "<td align='center'>" + no_5 + "</td>" +
                   "<td align='center'>" + no_6 + "</td>" +
                   "<td align='center'>" + no_7 + "</td>" +
                   "<td align='center'>" + no_8 + "</td>" +
                   "<td align='center'>" + no_9 + "</td>" +
                   "<td align='center'>" + created_at + "</td>" +
                //    "<td align='center'>Admin</td>" +
                   "</tr>";
                   $(".my-table tbody").append(tr_str);
                }
            // var tr_sum = "<tr>"+
            //                 "<td colspan='2'><strong>Total Points</strong></td>"+
            //                 "<td><strong>"+response['sum_points']+"</strong></td>"+
            //                 "<td colspan='2'></td>"+
            //                 "</tr>";
            //                 $(".my-table tbody").append(tr_sum);
            },error(data){
                console.log(data);
            }
        });
	}
    </script>

</body>

</html>
